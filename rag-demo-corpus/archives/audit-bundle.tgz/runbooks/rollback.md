# Rollback

Rollback 1. Tarball runbooks should be retrievable by nested path with citation-ready provenance.

Rollback 2. Tarball runbooks should be retrievable by nested path with citation-ready provenance.

Rollback 3. Tarball runbooks should be retrievable by nested path with citation-ready provenance.

Rollback 4. Tarball runbooks should be retrievable by nested path with citation-ready provenance.

Rollback 5. Tarball runbooks should be retrievable by nested path with citation-ready provenance.

Rollback 6. Tarball runbooks should be retrievable by nested path with citation-ready provenance.

Rollback 7. Tarball runbooks should be retrievable by nested path with citation-ready provenance.

Rollback 8. Tarball runbooks should be retrievable by nested path with citation-ready provenance.