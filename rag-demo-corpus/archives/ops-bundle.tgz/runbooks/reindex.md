# Reindex

Reindex notes say ingestion helpers should stay deterministic across backends.